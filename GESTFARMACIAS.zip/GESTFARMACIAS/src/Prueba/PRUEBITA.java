/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Prueba;

import Clases.*;

/**
 *
 * @author Rmiglio
 */
public class PRUEBITA 
{

    public static void main(String[] args) 
    {
        Gestion G1 = new Gestion(400,60);
        Gestion G2 = new Gestion(300,40);
        Gestion G3 = new Gestion(500,50);
        Gestion G4 = new Gestion(600,30);
        Gestion G5 = new Gestion(700,70);
        Gestion G6 = new Gestion(800,100);
        
        System.out.println("\nInkafarma");
        //public Inkafarma(int NumVigilantes, String Horario, String Distrito, float area, int personal)
        Inkafarma I1 = new Inkafarma(2,"6am a 3am","Surco",1000f,10);
        I1.CalcularValorización();
        I1.CalcularImpuesto();
        I1.CalcularSumapersonal();
        I1.IngresarFarmacia(G1);
        I1.IngresarFarmacia(G2);
        System.out.println(I1.VerInfo());
        I1.MostrarFarmacias();
        
        System.out.println("\nMifarma");
        // public Mifarma(int NumCamaras, String Horario, String Distrito, float area, int personal) 
        Mifarma M1 = new Mifarma(6,"5am a 2am","San Borja",1500.25f,7);
        M1.CalcularValorización();
        M1.CalcularImpuesto();
        M1.IngresarFarmacia(G3);
        M1.IngresarFarmacia(G4);
        System.out.println(M1.VerInfo());
        M1.MostrarFarmacias();
        
        System.out.println("\nFasa");
        // public Fasa(int NumPerros, String Horario, String Distrito, float area, int personal)
        Fasa F1 = new Fasa(3,"Abierto las 24 horas","San Isidro",500f,15);
        F1.CalcularValorización();
        F1.CalcularSumapersonal();
        F1.IngresarFarmacia(G5);
        F1.IngresarFarmacia(G6);
        System.out.println(F1.VerInfo());
        F1.MostrarFarmacias();
    }
    
    
}
