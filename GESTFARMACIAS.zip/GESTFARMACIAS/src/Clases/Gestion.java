/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Rmiglio
 */
public class Gestion 
{
    
    protected int entregas, Cliente;

    public Gestion(int entregas, int Cliente) {
        this.entregas = entregas;
        this.Cliente = Cliente;
    }

   
    public int getCliente() {
        return Cliente;
    }

    public void setCliente(int Cliente) {
        this.Cliente = Cliente;
    }
  
    public String VerInfo() {
        return  
                "\nEntrega de productos " + entregas + 
                "\nCliente: " + Cliente;
    }
    
    
    
    
    
}
