/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Rmiglio
 */
public class Inkafarma extends Farmacia implements Impuesto, SumaPersonal
{
    private int NumVigilantes,sumaPersonal;
    private float Impuesto;
    
   

    public Inkafarma(int NumVigilantes, String Horario, String Distrito, float area, int personal) {
        super(Horario, Distrito, area, personal);
        this.NumVigilantes = NumVigilantes;
    }

    public int getNumVigilantes() {
        return NumVigilantes;
    }

    public void setNumVigilantes(int NumVigilantes) {
        this.NumVigilantes = NumVigilantes;
    }

    public int getSumaPersonal() {
        return sumaPersonal;
    }

    public void setSumaPersonal(int sumaPersonal) {
        this.sumaPersonal = sumaPersonal;
    }

    public float getImpuesto() {
        return Impuesto;
    }

    public void setImpuesto(float Impuesto) {
        this.Impuesto = Impuesto;
    }
    
   
    public void CalcularImpuesto() {
        this.Impuesto = this.valorizacion*0.15f;
    }

   
    public void CalcularSumapersonal() {
       this.sumaPersonal = this.personal+this.NumVigilantes;
    }

  
    public String VerInfo() {
        return super.VerInfo() 
                + "\nNumero de Vigilantes: "+ NumVigilantes 
                + "\nSuma de Personal: " + sumaPersonal 
                + "\nImpuesto: " + Impuesto;
    
    

    
    
    
    
    
}

   
}
