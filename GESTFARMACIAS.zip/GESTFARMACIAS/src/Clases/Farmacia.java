/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Rmiglio
 */
public class Farmacia 
{
    
    protected String Horario,Distrito;
    protected float valorizacion,area;
    protected int personal;
    protected ArrayList<Gestion> arreglo;

    public Farmacia(String Horario, String Distrito, float area, int personal) {
        this.Horario = Horario;
        this.Distrito = Distrito;
        this.area = area;
        this.personal = personal;
        arreglo = new ArrayList<Gestion>();
    }

    

    public String getHorario() {
        return Horario;
    }

    public void setHorario(String Horario) {
        this.Horario = Horario;
    }

    public String getDistrito() {
        return Distrito;
    }

    public void setDistrito(String Distrito) {
        this.Distrito = Distrito;
    }

    public float getValorizacion() {
        return valorizacion;
    }

    public void setValorizacion(float valorizacion) {
        this.valorizacion = valorizacion;
    }

    public float getArea() {
        return area;
    }

    public void setArea(float area) {
        this.area = area;
    }

    public int getPersonal() {
        return personal;
    }

    public void setPersonal(int personal) {
        this.personal = personal;
    }
    
    
    public ArrayList<Gestion> getArreglo() {
        return arreglo;
    }

    public void setArreglo(ArrayList<Gestion> arreglo) {
        this.arreglo = arreglo;
    }
    
    
    
    public void IngresarFarmacia(Gestion objeto){
        arreglo.add(objeto);
    }
    
    public void MostrarFarmacias(){
        Iterator<Gestion> puntero = arreglo.iterator();
        while(puntero.hasNext()){
            Gestion a = puntero.next();
            System.out.println(a.VerInfo());
        }
    }

    public void CalcularValorización()
    {
        this.valorizacion = this.area*2500;
        
    }
    
    
    public String VerInfo() {
        return "Horario: " + Horario +
                "\nDistrito: " + Distrito + 
                "\nValorizacion: " + valorizacion +
                "\nArea: " + area + 
                "\nPersonal disponible: "+ personal;
        
    }
    
       
        
        
        
    }
    
    
    
    

