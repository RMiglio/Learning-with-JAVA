/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Rmiglio
 */
public class Fasa extends Farmacia implements SumaPersonal{
    
    private int NumPerros,Sumapersonal;

    public Fasa(int NumPerros, String Horario, String Distrito, float area, int personal) {
        super(Horario, Distrito, area, personal);
        this.NumPerros = NumPerros;
    }

    public int getNumPerros() {
        return NumPerros;
    }

    public void setNumPerros(int NumPerros) {
        this.NumPerros = NumPerros;
    }

    public int getSumapersonal() {
        return Sumapersonal;
    }

    public void setSumapersonal(int Sumapersonal) {
        this.Sumapersonal = Sumapersonal;
    }

    public void CalcularSumapersonal() {
       this.Sumapersonal = this.personal + this.NumPerros;
    }

  
    public String VerInfo() {
        return super.VerInfo() 
                + "\nNumero de Perros: " + NumPerros 
                + "\nSuma del personal:" + Sumapersonal;  
    }
    
    
    
    
    
    
}
