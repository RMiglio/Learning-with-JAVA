/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Rmiglio
 */
public class Mifarma  extends Farmacia implements Impuesto {
    
    private int NumCamaras;
    private float Impuesto;

    public Mifarma(int NumCamaras, String Horario, String Distrito, float area, int personal) {
        super(Horario, Distrito, area, personal);
        this.NumCamaras = NumCamaras;
    }

    public int getNumCamaras() {
        return NumCamaras;
    }

    public void setNumCamaras(int NumCamaras) {
        this.NumCamaras = NumCamaras;
    }

    public float getImpuesto() {
        return Impuesto;
    }

    public void setImpuesto(float Impuesto) {
        this.Impuesto = Impuesto;
    }
    


    public void CalcularImpuesto() {
       this.Impuesto = this.valorizacion * 0.10f;
    }

  
    public String VerInfo() {
        return super.VerInfo()
                + "\nNumero de Camaras: " + NumCamaras 
                + "\nImpuesto: " + Impuesto; 
    }
    
    
    
}
